import Menu from "./components/menu/menu"
import Rotas from "./Rotas";


function App(){
  return(
    <div className="App">
      <Menu/>
      <Rotas/>
    </div>
  );
}
export default App;