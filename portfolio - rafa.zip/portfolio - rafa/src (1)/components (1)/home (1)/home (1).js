import Header from "../../components/header/header"
import BasicCard from "../cards/basic-card";

export default function Home(){
  return (
  <>
    <Header />
      <div class="row">
        <BasicCard title="React" descricao="Biblioteca para criação de interfaces" />
        <BasicCard title="JSX" descricao=" JSX é uma extensão da sintaxe da linguagem JavaScript que fornece uma maneira de estruturar a renderização de componentes usando uma sintaxe familiar para muitos desenvolvedores. É semelhante ao HTML" />
      </div>
  </>

  );
}