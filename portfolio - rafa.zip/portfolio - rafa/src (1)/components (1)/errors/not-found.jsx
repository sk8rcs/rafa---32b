import BasicCard from "../cards/basic-card";

const NotFound = () => (
    <div className="row">
        <BasicCard titulo="404" descricao="Pagina não encontrada"/>
    </div>
);
export default NotFound;